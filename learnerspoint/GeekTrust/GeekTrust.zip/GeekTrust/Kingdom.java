package com.language.GeekTrust;

/**
 * Created by dbhattac on 5/24/2017.
 */
interface Kingdom {
}
