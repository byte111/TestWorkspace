package com.language.GeekTrust;

/**
 * Created by dbhattac on 5/24/2017.
 */
public interface IReigns {
    public void setRuler(Ruler ruler);
    public Ruler getRuler();
}
