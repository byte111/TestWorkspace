package com.language.GeekTrust;

/**
 * Created by dbhattac on 5/24/2017.
 */
class Ruler
{

    private String ruler;
    public String getRuler(){
        return ruler;
    }

    public void setRuler(String ruler)
    {
        this.ruler = ruler;
    }

}